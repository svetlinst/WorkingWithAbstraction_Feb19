﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HotelReservation
{
    public enum DiscountType
    {
        None,
        SecondVisit = 10,
        VIP=20
    }
}
