﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04_Hospital
{
    class Doctor
    {
    }
}
